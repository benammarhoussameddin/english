
import { useEffect, useState } from 'react'
import Router from 'next/router'
export default function Checkout(){
  const [cart,setCart] = useState([])
  const [name,setName] = useState('')
  const [phone,setPhone] = useState('')
  const [address,setAddress] = useState('')
  useEffect(()=> setCart(JSON.parse(localStorage.getItem('cart')||'[]')),[])
  async function placeOrder(){
    if(!name || !phone || cart.length===0){ alert('املأ الحقول'); return }
    const order = { id: Date.now().toString(), items: cart, name, phone, address, payment:'COD', total: cart.reduce((s,i)=>s + i.price*i.qty,0), state:'new', createdAt: new Date().toISOString() }
    const res = await fetch('/api/orders', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(order) })
    if(res.ok){ localStorage.removeItem('cart'); alert('تم إرسال الطلب'); Router.push('/') } else alert('خطأ')
  }
  return (
    <div>
      <h2>تأكيد الطلب</h2>
      <label>الاسم</label><br/><input value={name} onChange={e=>setName(e.target.value)}/><br/>
      <label>الهاتف</label><br/><input value={phone} onChange={e=>setPhone(e.target.value)}/><br/>
      <label>العنوان</label><br/><textarea value={address} onChange={e=>setAddress(e.target.value)}/><br/>
      <div style={{marginTop:12}}><div>الدفع عند الاستلام</div><button onClick={placeOrder} style={{background:'#000',color:'#D4AF37',padding:10,borderRadius:6,marginTop:8}}>تأكيد الطلب</button></div>
    </div>
  )
}
