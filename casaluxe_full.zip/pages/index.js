
import fs from 'fs'
import path from 'path'
import Link from 'next/link'
export default function Home({products}){
  return (
    <div>
      <h1 style={{textAlign:'center',color:'#D4AF37'}}>CasaLuxe DZ</h1>
      <p style={{textAlign:'center'}}>لمسة فخامة في كل بيت — Luxury for Every Home</p>
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(240px,1fr))',gap:18,marginTop:20}}>
        {products.map(p=>(
          <div key={p.id} style={{border:'1px solid #eee',padding:12,borderRadius:6}}>
            <img src={p.image} style={{width:'100%',height:180,objectFit:'cover'}}/>
            <h3>{p.title.ar}</h3>
            <div style={{fontWeight:800}}>{p.price} {p.currency}</div>
            <Link href={`/product/${p.id}`}><a style={{background:'#000',color:'#D4AF37',padding:8,borderRadius:6,display:'inline-block',marginTop:8}}>عرض المنتج</a></Link>
          </div>
        ))}
      </div>
    </div>
  )
}
export async function getStaticProps(){
  const filePath = path.join(process.cwd(),'data','db.json')
  const db = JSON.parse(fs.readFileSync(filePath,'utf8'))
  return { props: { products: db.products } }
}
