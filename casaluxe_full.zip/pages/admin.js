
import { useEffect, useState } from 'react'
const ADMIN_PASS = process.env.NEXT_PUBLIC_ADMIN_PASS || 'casaluxeadmin'
export default function Admin(){
  const [auth,setAuth] = useState(false)
  const [orders,setOrders] = useState([])
  useEffect(()=>{
    const url = new URL(window.location.href)
    if(url.searchParams.get('pass') === ADMIN_PASS) setAuth(true)
  },[])
  useEffect(()=>{ if(auth) fetch('/api/orders').then(r=>r.json()).then(d=>setOrders(d)) },[auth])
  if(!auth) return <div>Admin - protected. Add ?pass=YOUR_PASS to URL</div>
  return (
    <div>
      <h2>لوحة الإدارة - الطلبات</h2>
      {orders.length===0 ? <div>لا طلبات</div> :
        orders.map(o=>(
          <div key={o.id} style={{border:'1px solid #eee',padding:12,marginBottom:8}}>
            <div><b>رقم:</b> {o.id} — <b>المجموع:</b> {o.total} DZD</div>
            <div><b>اسم:</b> {o.name} — <b>هاتف:</b> {o.phone}</div>
            <div><b>العنوان:</b> {o.address}</div>
            <div><b>المنتجات:</b> {o.items.map(i=> i.title + ' x' + i.qty).join(', ')}</div>
          </div>
        ))
      }
    </div>
  )
}
