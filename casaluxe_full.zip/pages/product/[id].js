
import fs from 'fs'
import path from 'path'
import Router from 'next/router'
export default function ProductPage({product}){
  if(!product) return <div>Not found</div>
  function addToCart(){ 
    const cart = JSON.parse(localStorage.getItem('cart')||'[]')
    const found = cart.find(c=>c.id===product.id)
    if(found) found.qty += 1; else cart.push({id:product.id, title:product.title.ar, price:product.price, qty:1})
    localStorage.setItem('cart', JSON.stringify(cart))
    Router.push('/cart')
  }
  return (
    <div style={{display:'flex',gap:20}}>
      <img src={product.image} style={{width:420,height:420,objectFit:'cover'}}/>
      <div>
        <h2 style={{color:'#D4AF37'}}>{product.title.ar}</h2>
        <p>{product.description.ar}</p>
        <div style={{fontWeight:800}}>{product.price} {product.currency}</div>
        <button onClick={addToCart} style={{background:'#000',color:'#D4AF37',padding:10,borderRadius:6,marginTop:12}}>أضف إلى السلة</button>
      </div>
    </div>
  )
}
export async function getStaticPaths(){
  const filePath = path.join(process.cwd(),'data','db.json')
  const db = JSON.parse(fs.readFileSync(filePath,'utf8'))
  return { paths: db.products.map(p=>({ params:{ id: p.id }})), fallback:false }
}
export async function getStaticProps({params}){
  const filePath = path.join(process.cwd(),'data','db.json')
  const db = JSON.parse(fs.readFileSync(filePath,'utf8'))
  const product = db.products.find(p=>p.id===params.id) || null
  return { props: { product } }
}
