
import { promises as fs } from 'fs'
import path from 'path'
export default async function handler(req,res){
  const filePath = path.join(process.cwd(),'data','db.json')
  try{
    const content = await fs.readFile(filePath,'utf8')
    const db = JSON.parse(content)
    return res.status(200).json(db.products)
  } catch(err){ return res.status(500).json({error: err.toString()}) }
}
