
import { promises as fs } from 'fs'
import path from 'path'
export default async function handler(req,res){
  const filePath = path.join(process.cwd(),'data','db.json')
  try{
    const content = await fs.readFile(filePath,'utf8')
    const db = JSON.parse(content)
    if(req.method === 'POST'){
      const order = req.body
      db.orders.push(order)
      await fs.writeFile(filePath, JSON.stringify(db, null, 2))
      return res.status(201).json({ok:true})
    } else if(req.method === 'GET'){
      return res.status(200).json(db.orders)
    } else { res.setHeader('Allow',['GET','POST']); return res.status(405).end('Method not allowed') }
  } catch(err){ return res.status(500).json({error: err.toString()}) }
}
