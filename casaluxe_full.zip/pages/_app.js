
import '../styles.css'
import Header from '../components/Header'
export default function App({Component, pageProps}){
  return (
    <div>
      <Header/>
      <main style={{padding:20,maxWidth:1100,margin:'0 auto'}}><Component {...pageProps} /></main>
    </div>
  )
}
