
import { useEffect, useState } from 'react'
import Router from 'next/router'
export default function Cart(){
  const [cart,setCart] = useState([])
  useEffect(()=> setCart(JSON.parse(localStorage.getItem('cart')||'[]')),[])
  function updateQty(idx,delta){
    const c = cart.slice()
    c[idx].qty = Math.max(1,c[idx].qty+delta)
    setCart(c); localStorage.setItem('cart', JSON.stringify(c))
  }
  function total(){ return cart.reduce((s,i)=>s + i.price*i.qty, 0) }
  if(cart.length===0) return <div><h3>السلة فارغة</h3></div>
  return (
    <div>
      <h2>السلة</h2>
      {cart.map((it,idx)=>(
        <div key={it.id} style={{display:'flex',justifyContent:'space-between',padding:12,borderBottom:'1px solid #eee'}}>
          <div><div><b>{it.title}</b></div><div>{it.price} DZD</div></div>
          <div>
            <button onClick={()=>updateQty(idx,-1)}>-</button>
            <span style={{margin:'0 8px'}}>{it.qty}</span>
            <button onClick={()=>updateQty(idx,1)}>+</button>
          </div>
        </div>
      ))}
      <h3>المجموع: {total()} DZD</h3>
      <button onClick={()=>Router.push('/checkout')} style={{background:'#000',color:'#D4AF37',padding:8,borderRadius:6}}>الدفع</button>
    </div>
  )
}
