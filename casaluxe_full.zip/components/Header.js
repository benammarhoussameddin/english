
import Link from 'next/link'
export default function Header(){ 
  return (
    <header style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:16,background:'#000',color:'#D4AF37'}}>
      <div style={{fontWeight:700,fontSize:20}}>CasaLuxe DZ</div>
      <nav>
        <Link href='/'><a style={{color:'#fff',marginRight:12}}>Home</a></Link>
        <Link href='/products'><a style={{color:'#fff',marginRight:12}}>Products</a></Link>
        <Link href='/admin'><a style={{color:'#fff'}}>Admin</a></Link>
      </nav>
    </header>
  )
}
