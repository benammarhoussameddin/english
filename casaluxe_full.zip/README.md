
CasaLuxe Store - Starter Next.js project
---------------------------------------
What's included:
- pages: index, product/[id], cart, checkout, admin
- simple API endpoints saving orders to data/db.json
- components: Header, Layout, ProductCard
- data/db.json: products + empty orders
- public/: placeholder images and logo

Run locally:
1) npm install
2) npm run dev
3) Open http://localhost:3000
